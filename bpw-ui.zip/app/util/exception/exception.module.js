(function() {
  'use strict';

  angular.module('util.exception', ['util.logger']);
})();
