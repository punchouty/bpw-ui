(function() {
  'use strict';

  angular.module('util.directives', [
    'ui.router',
    'util.logger'
  ]);
})();
