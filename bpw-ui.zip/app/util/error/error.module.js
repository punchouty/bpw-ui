(function() {
  'use strict';

  angular.module('util.error', [
       
   ]);

 

})();