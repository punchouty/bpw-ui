(function() {
  'use strict';

  angular.module('util.router', [
    'ui.router',
    'util.logger',
    'util.auth'
  ]);
})();
