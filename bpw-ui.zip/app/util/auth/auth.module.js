(function() {
  'use strict';

  angular.module('util.auth', [
       'util.env', 
       'util.logger',
       'util.help',
       'app',
       'ngStorage'
   ]);
})();
