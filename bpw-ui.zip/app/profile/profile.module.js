(function() {
  'use strict';

  angular.module('app.profile', [
	'util.env', 
	'util.logger',
	'util.auth'
   ]);
})();
